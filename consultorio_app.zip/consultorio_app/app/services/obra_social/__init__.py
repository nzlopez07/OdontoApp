"""
Inicializador del módulo de servicios de obra social.
"""

from .buscar_obras_sociales_service import BuscarObrasSocialesService

__all__ = [
    'BuscarObrasSocialesService',
]
