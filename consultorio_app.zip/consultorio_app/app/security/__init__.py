"""
Inicializador del módulo security.
"""

from .rate_limiter import RateLimiter

__all__ = ["RateLimiter"]
