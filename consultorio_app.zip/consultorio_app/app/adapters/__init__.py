"""
Inicializador del módulo adapters (canales externos).
"""

__all__ = []
