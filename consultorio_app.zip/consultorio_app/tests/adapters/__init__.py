"""
Inicializador de tests de adapters.
"""

__all__ = []
